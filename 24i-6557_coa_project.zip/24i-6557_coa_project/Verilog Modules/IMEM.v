module IMEM(
    input [31:0] PC,
    output reg [31:0] Inst
);

reg [31:0] Memory [0:255];
integer i;

initial begin
    for (i = 0; i < 256; i = i + 1)
        Memory[i] = 32'h00000000;

    Memory[0] = 32'h00A00093;
    Memory[1] = 32'h01400113;
    Memory[2] = 32'h002081B3;
    Memory[3] = 32'h00302023;
    Memory[4] = 32'h00002203;
    Memory[5] = 32'h00418463;
    Memory[6] = 32'h00100293;
    Memory[7] = 32'h0080036F;
end

always @(*) begin
    if (PC[31:10] == 0)
        Inst = Memory[PC[9:2]];
    else
        Inst = 32'h00000000;
end

endmodule
