module ALU (
    input [31:0] A,
    input [31:0] B,
    input [3:0] ALUSel,
    output reg [31:0] ALU_OUT
);

always @(*) begin
    case (ALUSel)
        4'b0000: ALU_OUT = A + B;
        4'b0001: ALU_OUT = A - B;
        4'b0010: ALU_OUT = A << B[4:0];
        4'b0011: ALU_OUT = ($signed(A) < $signed(B)) ? 32'd1 : 32'd0;
        4'b0100: ALU_OUT = (A < B) ? 32'd1 : 32'd0;
        4'b0101: ALU_OUT = A ^ B;
        4'b0110: ALU_OUT = A >> B[4:0];
        4'b0111: ALU_OUT = $signed(A) >>> B[4:0];
        4'b1000: ALU_OUT = A | B;
        4'b1001: ALU_OUT = A & B;
        4'b1010: ALU_OUT = B;
        default: ALU_OUT = 32'd0;
    endcase
end

endmodule


module tb_ALU;

reg [31:0] A;
reg [31:0] B;
reg [3:0] ALUSel;
wire [31:0] ALU_OUT;

ALU uut (
    .A(A),
    .B(B),
    .ALUSel(ALUSel),
    .ALU_OUT(ALU_OUT)
);

initial begin

    A = 32'h00000003;
    B = 32'h00000003;
    ALUSel = 4'b0000;
    #10;

    A = 32'hFFFFFFFD;
    B = 32'h00000007;
    ALUSel = 4'b0000;
    #10;

    A = 32'hFFFFFFFC;
    B = 32'h00000001;
    ALUSel = 4'b0001;
    #10;

    A = 32'h00000007;
    B = 32'h00000007;
    ALUSel = 4'b0001;
    #10;

    A = 32'h00000001;
    B = 32'h00000004;
    ALUSel = 4'b0010;
    #10;

    A = 32'hFFFFFFFF;
    B = 32'h00000001;
    ALUSel = 4'b0011;
    #10;

    A = 32'hFFFFFFFF;
    B = 32'h00000001;
    ALUSel = 4'b0100;
    #10;

    A = 32'hAAAAAAAA;
    B = 32'hFFFF0000;
    ALUSel = 4'b0101;
    #10;

    A = 32'h80000000;
    B = 32'h00000004;
    ALUSel = 4'b0110;
    #10;

    A = 32'h80000000;
    B = 32'h00000004;
    ALUSel = 4'b0111;
    #10;

    A = 32'h0000F0F0;
    B = 32'h00000F0F;
    ALUSel = 4'b1000;
    #10;

    A = 32'hFFFF00FF;
    B = 32'h0F0F0F0F;
    ALUSel = 4'b1001;
    #10;

    A = 32'h12345678;
    B = 32'hABCDE000;
    ALUSel = 4'b1010;
    #10;

    $finish;
end

endmodule
