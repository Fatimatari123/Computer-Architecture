// ---------- Module ----------
module Adder_Subtractor_32bit (
    input  [31:0] A,
    input  [31:0] B,
    input         SUB,         
    output [31:0] SUM,
    output        COUT,
    output        Overflow,    
    output [31:0] SLT_out,     
    output [31:0] SLTU_out     
);
   
    wire [31:0] B_x = B ^ {32{SUB}};

    Adder_32bit add32 (.a(A), .b(B_x), .cin(SUB), .sum(SUM), .cout(COUT));

    assign Overflow = ~(A[31] ^ B_x[31]) & (A[31] ^ SUM[31]);
    assign SLTU_out = {31'b0, ~COUT};
    assign SLT_out  = {31'b0, ((A[31] ^ B[31]) ? A[31] : SUM[31])};
endmodule


module tb_Adder_Subtractor_32bit;
    reg  [31:0] A, B;
    reg         SUB;
    wire [31:0] SUM, SLT_out, SLTU_out;
    wire        COUT, Overflow;

    Adder_Subtractor_32bit dut (.A(A), .B(B), .SUB(SUB), .SUM(SUM), .COUT(COUT),
                                .Overflow(Overflow), .SLT_out(SLT_out), .SLTU_out(SLTU_out));

    initial begin
        A = 32'h00000005; B = 32'h00000003; SUB = 0; #10;
        A = 32'h7FFFFFFF; B = 32'h00000001; SUB = 0; #10;
        A = 32'hFFFFFFFF; B = 32'h00000001; SUB = 0; #10;
        A = 32'h00000005; B = 32'h00000003; SUB = 1; #10;
        A = 32'h00000003; B = 32'h00000005; SUB = 1; #10;
        A = 32'h80000000; B = 32'h00000001; SUB = 1; #10;
        A = 32'hFFFFFFFF; B = 32'h00000001; SUB = 1; #10;
        A = 32'h7FFFFFFF; B = 32'h80000000; SUB = 1; #10;
        A = 32'h00000007; B = 32'h00000007; SUB = 1; #10;
        $stop;
    end
endmodule
