
module Full_Adder (
    input  a,
    input  b,
    input  cin,
    output sum,
    output cout
);
    wire s1, c1, c2;

    Half_adder ha1 (.a(a),  .b(b),   .sum(s1),  .carry(c1));
    Half_adder ha2 (.a(s1), .b(cin), .sum(sum), .carry(c2));
    or (cout, c1, c2);
endmodule


module tb_Full_Adder;
    reg  a, b, cin;
    wire sum, cout;
    integer i;

    Full_Adder dut (.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

    initial begin
        for (i = 0; i < 8; i = i + 1) begin
            {a, b, cin} = i[2:0];
            #10;
        end
        $stop;
    end
endmodule
