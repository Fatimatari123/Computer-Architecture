module tb_Processor;

reg CLK;
reg RESET;

wire [31:0] PC;
wire [31:0] Inst;
wire [31:0] ALU_OUT;
wire [31:0] DataA;
wire [31:0] DataB;
wire [31:0] Imm;
wire [31:0] DataR;
wire [31:0] DataW;
wire PCSel;
wire RegWEn;
wire MemRW;

Processor uut (
    .CLK(CLK),
    .RESET(RESET),
    .PC(PC),
    .Inst(Inst),
    .ALU_OUT(ALU_OUT),
    .DataA(DataA),
    .DataB(DataB),
    .Imm(Imm),
    .DataR(DataR),
    .DataW(DataW),
    .PCSel(PCSel),
    .RegWEn(RegWEn),
    .MemRW(MemRW)
);

initial begin
    CLK = 0;
    forever #5 CLK = ~CLK;
end

initial begin
    RESET = 1;
    #20;
    RESET = 0;
    #150;
    $finish;
end

endmodule
