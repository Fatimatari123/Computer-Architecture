
module Logic32 (
    input  [31:0] A,
    input  [31:0] B,
    output [31:0] AND_out,
    output [31:0] OR_out,
    output [31:0] XOR_out
);
    assign AND_out = A & B;
    assign OR_out  = A | B;
    assign XOR_out = A ^ B;
endmodule


module tb_Logic32;
    reg  [31:0] A, B;
    wire [31:0] AND_out, OR_out, XOR_out;

    Logic32 dut (.A(A), .B(B), .AND_out(AND_out), .OR_out(OR_out), .XOR_out(XOR_out));

    initial begin
        A = 32'hAAAAAAAA; B = 32'hFFFF0000; #10;   
        A = 32'h0000F0F0; B = 32'h00000F0F; #10;  
        A = 32'hFFFF00FF; B = 32'h0F0F0F0F; #10;   
        A = 32'hF0F0F0F0; B = 32'h0FF00FF0; #10;
        A = 32'h00000000; B = 32'hFFFFFFFF; #10;
        A = 32'hFFFFFFFF; B = 32'hFFFFFFFF; #10;
        A = 32'h12345678; B = 32'h00000000; #10;
        $stop;
    end
endmodule
