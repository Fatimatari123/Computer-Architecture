module PC(
    input clk,
    input reset,
    input PCSel,
    input [31:0] target,
    output reg [31:0] pc
);

wire [31:0] pc4;
wire [31:0] next_pc;

assign pc4 = pc + 32'd4;
assign next_pc = PCSel ? target : pc4;

always @(posedge clk)
begin
    if (reset)
        pc <= 32'h00000000;
    else
        pc <= next_pc;
end

endmodule


module PC_Testbench;

reg clk;
reg reset;
reg PCSel;
reg [31:0] target;

wire [31:0] pc;
reg [31:0] expected_pc;

PC uut(
    .clk(clk),
    .reset(reset),
    .PCSel(PCSel),
    .target(target),
    .pc(pc)
);

initial
begin
    clk = 0;
    forever #5 clk = ~clk;
end

initial
begin
    reset = 1;
    PCSel = 0;
    target = 32'h00000000;
    expected_pc = 32'h00000000;

    #10;

    reset = 0;
    PCSel = 0;
    expected_pc = 32'h00000004;

    #10;
    expected_pc = 32'h00000008;

    #10;
    expected_pc = 32'h0000000C;

    #10;
    PCSel = 1;
    target = 32'h00000040;
    expected_pc = 32'h00000040;

    #10;
    $finish;
end

endmodule
