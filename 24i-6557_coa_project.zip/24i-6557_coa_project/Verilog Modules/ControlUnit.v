module ControlUnit(
    input [31:0] Inst,
    input BrEq,
    input BrLT,

    output reg PCSel,
    output reg [2:0] ImmSel,
    output reg RegWEn,
    output reg BrUn,
    output reg Asel,
    output reg Bsel,
    output reg [3:0] ALUSel,
    output reg MemRW,
    output reg [1:0] WBSel
);

wire [6:0] opcode;
wire [2:0] funct3;
wire funct7_5;

assign opcode = Inst[6:0];
assign funct3 = Inst[14:12];
assign funct7_5 = Inst[30];

always @(*) begin

    PCSel = 0;
    ImmSel = 0;
    RegWEn = 0;
    BrUn = 0;
    Asel = 0;
    Bsel = 0;
    ALUSel = 4'b0000;
    MemRW = 0;
    WBSel = 2'b01;

    case (opcode)

        // R-Type
        7'b0110011: begin
            RegWEn = 1;
            Asel = 0;
            Bsel = 0;
            WBSel = 2'b01;

            case (funct3)
                3'b000: ALUSel = funct7_5 ? 4'b0001 : 4'b0000;
                3'b001: ALUSel = 4'b0010;
                3'b010: ALUSel = 4'b0011;
                3'b011: ALUSel = 4'b0100;
                3'b100: ALUSel = 4'b0101;
                3'b101: ALUSel = funct7_5 ? 4'b0111 : 4'b0110;
                3'b110: ALUSel = 4'b1000;
                3'b111: ALUSel = 4'b1001;
            endcase
        end

        // I-Type ALU
        7'b0010011: begin
            RegWEn = 1;
            Bsel = 1;
            WBSel = 2'b01;

            case (funct3)
                3'b000: ALUSel = 4'b0000;
                3'b001: ALUSel = 4'b0010;
                3'b010: ALUSel = 4'b0011;
                3'b011: ALUSel = 4'b0100;
                3'b100: ALUSel = 4'b0101;
                3'b101: ALUSel = funct7_5 ? 4'b0111 : 4'b0110;
                3'b110: ALUSel = 4'b1000;
                3'b111: ALUSel = 4'b1001;
            endcase
        end

        // Loads
        7'b0000011: begin
            ImmSel = 3'b000;
            RegWEn = 1;
            Bsel = 1;
            ALUSel = 4'b0000;
            MemRW = 0;
            WBSel = 2'b00;
        end

        // Stores
        7'b0100011: begin
            ImmSel = 3'b001;
            Bsel = 1;
            ALUSel = 4'b0000;
            MemRW = 1;
            RegWEn = 0;
        end

        // Branches
        7'b1100011: begin
            ImmSel = 3'b010;
            RegWEn = 0;
            Asel = 1;
            Bsel = 1;
            ALUSel = 4'b0000;
            MemRW = 0;

            case (funct3)
                3'b000: PCSel = BrEq;       // BEQ
                3'b001: PCSel = !BrEq;      // BNE
                3'b100: begin               // BLT
                    BrUn = 0;
                    PCSel = BrLT;
                end
                3'b101: begin               // BGE
                    BrUn = 0;
                    PCSel = !BrLT;
                end
                3'b110: begin               // BLTU
                    BrUn = 1;
                    PCSel = BrLT;
                end
                3'b111: begin               // BGEU
                    BrUn = 1;
                    PCSel = !BrLT;
                end
                default: PCSel = 0;
            endcase
        end

        // JAL
        7'b1101111: begin
            PCSel = 1;
            ImmSel = 3'b100;
            RegWEn = 1;
            Asel = 1;
            Bsel = 1;
            ALUSel = 4'b0000;
            MemRW = 0;
            WBSel = 2'b10;
        end

        // JALR
        7'b1100111: begin
            PCSel = 1;
            ImmSel = 3'b000;
            RegWEn = 1;
            Asel = 0;
            Bsel = 1;
            ALUSel = 4'b0000;
            MemRW = 0;
            WBSel = 2'b10;
        end

        // LUI
        7'b0110111: begin
            ImmSel = 3'b011;
            RegWEn = 1;
            Bsel = 1;
            ALUSel = 4'b1010;
            MemRW = 0;
            WBSel = 2'b01;
        end

        // AUIPC
        7'b0010111: begin
            ImmSel = 3'b011;
            RegWEn = 1;
            Asel = 1;
            Bsel = 1;
            ALUSel = 4'b0000;
            MemRW = 0;
            WBSel = 2'b01;
        end

    endcase
end

endmodule
