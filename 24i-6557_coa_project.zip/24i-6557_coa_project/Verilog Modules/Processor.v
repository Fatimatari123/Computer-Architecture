module Processor(
    input CLK,
    input RESET,

    output reg [31:0] PC,
    output [31:0] Inst,
    output [31:0] ALU_OUT,
    output [31:0] DataA,
    output [31:0] DataB,
    output [31:0] Imm,
    output [31:0] DataR,
    output [31:0] DataW,
    output PCSel,
    output RegWEn,
    output MemRW
);

reg [31:0] Regs [0:31];

wire [2:0] ImmSel;
wire BrUn;
wire Asel;
wire Bsel;
wire [3:0] ALUSel;
wire [1:0] WBSel;

wire BrEq;
wire BrLT;

wire [31:0] ALU_A;
wire [31:0] ALU_B;
wire [31:0] PC4;
wire [31:0] Target;

integer i;

// Register file initialization
initial begin
    for (i = 0; i < 32; i = i + 1)
        Regs[i] = 32'b0;
end

// PC + 4
assign PC4 = PC + 32'd4;

// Register reads
assign DataA = (Inst[19:15] == 0) ? 32'b0 : Regs[Inst[19:15]];
assign DataB = (Inst[24:20] == 0) ? 32'b0 : Regs[Inst[24:20]];

// Immediate Generator
ImmGen IG (
    .Inst(Inst),
    .ImmSel(ImmSel),
    .Imm(Imm)
);

// Branch Comparator
BranchComparator BC (
    .A(DataA),
    .B(DataB),
    .BrUn(BrUn),
    .BrEq(BrEq),
    .BrLT(BrLT)
);

// Control Unit
ControlUnit CU (
    .Inst(Inst),
    .BrEq(BrEq),
    .BrLT(BrLT),
    .PCSel(PCSel),
    .ImmSel(ImmSel),
    .RegWEn(RegWEn),
    .BrUn(BrUn),
    .Asel(Asel),
    .Bsel(Bsel),
    .ALUSel(ALUSel),
    .MemRW(MemRW),
    .WBSel(WBSel)
);

// ALU input selection
assign ALU_A = Asel ? PC : DataA;
assign ALU_B = Bsel ? Imm : DataB;

// ALU
ALU AU (
    .A(ALU_A),
    .B(ALU_B),
    .ALUSel(ALUSel),
    .ALU_OUT(ALU_OUT)
);

// Target address
assign Target = (Inst[6:0] == 7'b1100111)
              ? (ALU_OUT & 32'hFFFFFFFE)
              : ALU_OUT;

// Instruction Memory
IMEM IM (
    .PC(PC),
    .Inst(Inst)
);

// Data Memory
DMEM DM (
    .CLK(CLK),
    .addr(ALU_OUT),
    .DataW(DataB),
    .MemRW(MemRW),
    .funct3(Inst[14:12]),
    .DataR(DataR)
);

// Write Back MUX
assign DataW = (WBSel == 2'b00) ? DataR :
               (WBSel == 2'b01) ? ALU_OUT :
               (WBSel == 2'b10) ? PC4 :
               32'b0;

// Register write
always @(posedge CLK) begin
    if (RESET) begin
        for (i = 0; i < 32; i = i + 1)
            Regs[i] <= 32'b0;
    end
    else begin
        if (RegWEn && (Inst[11:7] != 5'b0))
            Regs[Inst[11:7]] <= DataW;

        Regs[0] <= 32'b0;
    end
end

// Program Counter
always @(posedge CLK) begin
    if (RESET)
        PC <= 32'b0;
    else if (PCSel)
        PC <= Target;
    else
        PC <= PC4;
end

endmodule
