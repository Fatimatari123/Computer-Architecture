
module DMEM (
    input CLK,
    input [31:0] addr,
    input [31:0] DataW,
    input MemRW,
    input [2:0] funct3,
    output reg [31:0] DataR
);

reg [7:0] Memory [0:4095];

integer i;

initial begin
    for (i = 0; i < 4096; i = i + 1)
        Memory[i] = 8'b0;
end

always @(posedge CLK) begin
    if (MemRW) begin
        case (funct3)
            3'b000: Memory[addr] <= DataW[7:0];
            3'b001: begin
                Memory[addr]     <= DataW[7:0];
                Memory[addr + 1] <= DataW[15:8];
            end
            3'b010: begin
                Memory[addr]     <= DataW[7:0];
                Memory[addr + 1] <= DataW[15:8];
                Memory[addr + 2] <= DataW[23:16];
                Memory[addr + 3] <= DataW[31:24];
            end
        endcase
    end
end

always @(*) begin
    case (funct3)
        3'b000: DataR = {{24{Memory[addr][7]}}, Memory[addr]};
        3'b001: DataR = {{16{Memory[addr + 1][7]}}, Memory[addr + 1], Memory[addr]};
        3'b010: DataR = {Memory[addr + 3], Memory[addr + 2], Memory[addr + 1], Memory[addr]};
        3'b100: DataR = {24'b0, Memory[addr]};
        3'b101: DataR = {16'b0, Memory[addr + 1], Memory[addr]};
        default: DataR = 32'b0;
    endcase
end

endmodule


module DMEM_TB;

reg CLK;
reg [31:0] addr;
reg [31:0] DataW;
reg MemRW;
reg [2:0] funct3;
wire [31:0] DataR;

DMEM uut (
    .CLK(CLK),
    .addr(addr),
    .DataW(DataW),
    .MemRW(MemRW),
    .funct3(funct3),
    .DataR(DataR)
);

initial begin
    CLK = 0;
    forever #5 CLK = ~CLK;
end

initial begin
    addr = 32'h00000014;
    DataW = 32'hDEADBEEF;
    MemRW = 1;
    funct3 = 3'b010;

    #10;
    MemRW = 0;
    funct3 = 3'b010;

    #10;
    funct3 = 3'b000;

    #10;
    funct3 = 3'b100;

    #10;
    funct3 = 3'b001;

    #10;
    addr = 32'h00000015;
    DataW = 32'h000000AA;
    MemRW = 1;
    funct3 = 3'b000;

    #10;
    addr = 32'h00000014;
    MemRW = 0;
    funct3 = 3'b010;

    #20;
    $finish;
end

endmodule

