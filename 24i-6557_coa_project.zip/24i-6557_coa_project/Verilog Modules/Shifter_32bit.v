
module Shifter_32bit (
    input  [31:0] A,
    input  [31:0] B,          
    output [31:0] SLL_out,
    output [31:0] SRA_out,
    output [31:0] SRL_out
);
    wire [4:0] shamt = B[4:0];

    assign SLL_out = A << shamt;                
    assign SRL_out = A >> shamt;                 
    assign SRA_out = $signed(A) >>> shamt;       
endmodule

module tb_Shifter_32bit;
    reg  [31:0] A, B;
    wire [31:0] SLL_out, SRA_out, SRL_out;

    Shifter_32bit dut (.A(A), .B(B), .SLL_out(SLL_out), .SRA_out(SRA_out), .SRL_out(SRL_out));

    initial begin
        A = 32'h00000001; B = 32'h00000004; #10;  
        A = 32'h80000000; B = 32'h00000004; #10;   
        A = 32'h00000001; B = 32'h0000001F; #10;
        A = 32'h00000001; B = 32'h00000024; #10;   
        A = 32'h80000000; B = 32'h0000001F; #10;
        A = 32'h12345678; B = 32'h00000008; #10;
        A = 32'h7FFFFFFF; B = 32'h0000001F; #10;
        A = 32'hFFFFFFFF; B = 32'h00000000; #10;   
        $stop;
    end
endmodule
