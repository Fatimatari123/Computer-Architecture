
module Half_adder (
    input  a,
    input  b,
    output sum,
    output carry
);
    xor (sum,   a, b);
    and (carry, a, b);
endmodule
module tb_Half_adder;
    reg  a, b;
    wire sum, carry;
    integer i;

    Half_adder dut (.a(a), .b(b), .sum(sum), .carry(carry));

    initial begin
        for (i = 0; i < 4; i = i + 1) begin
            {a, b} = i[1:0];
            #10;
        end
        $stop;
    end
endmodule