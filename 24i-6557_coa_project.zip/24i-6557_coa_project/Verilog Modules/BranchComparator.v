
module BranchComparator(
    input [31:0] A,
    input [31:0] B,
    input BrUn,
    output BrEq,
    output BrLT
);

assign BrEq = (A == B);
assign BrLT = BrUn ? (A < B) : ($signed(A) < $signed(B));

endmodule


module BranchComparator_Testbench;

reg [31:0] A;
reg [31:0] B;
reg BrUn;

wire BrEq;
wire BrLT;

reg Expected_BrEq;
reg Expected_BrLT;

BranchComparator uut(
    .A(A),
    .B(B),
    .BrUn(BrUn),
    .BrEq(BrEq),
    .BrLT(BrLT)
);

initial
begin
    A = 32'h00000005;
    B = 32'h00000005;
    BrUn = 0;
    Expected_BrEq = 1;
    Expected_BrLT = 0;
    #10;

    A = 32'hFFFFFFFF;
    B = 32'h00000001;
    BrUn = 0;
    Expected_BrEq = 0;
    Expected_BrLT = 1;
    #10;

    A = 32'hFFFFFFFF;
    B = 32'h00000001;
    BrUn = 1;
    Expected_BrEq = 0;
    Expected_BrLT = 0;
    #10;

    A = 32'h00000002;
    B = 32'h00000009;
    BrUn = 0;
    Expected_BrEq = 0;
    Expected_BrLT = 1;
    #10;

    $finish;
end

endmodule

