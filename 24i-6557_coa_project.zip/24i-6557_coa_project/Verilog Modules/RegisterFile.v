module RegisterFile (
    input CLK,
    input RegWEn,
    input [4:0] AddrA,
    input [4:0] AddrB,
    input [4:0] AddrD,
    input [31:0] DataD,
    output [31:0] DataA,
    output [31:0] DataB
);

reg [31:0] Reg [0:31];

assign DataA = (AddrA == 5'd0) ? 32'd0 : Reg[AddrA];
assign DataB = (AddrB == 5'd0) ? 32'd0 : Reg[AddrB];

always @(posedge CLK) begin
    if (RegWEn && AddrD != 5'd0)
        Reg[AddrD] <= DataD;
end

integer i;

initial begin
    for (i = 0; i < 32; i = i + 1)
        Reg[i] = 32'd0;
end

endmodule


module tb_RegisterFile;

reg CLK;
reg RegWEn;
reg [4:0] AddrA;
reg [4:0] AddrB;
reg [4:0] AddrD;
reg [31:0] DataD;

wire [31:0] DataA;
wire [31:0] DataB;

RegisterFile uut (
    .CLK(CLK),
    .RegWEn(RegWEn),
    .AddrA(AddrA),
    .AddrB(AddrB),
    .AddrD(AddrD),
    .DataD(DataD),
    .DataA(DataA),
    .DataB(DataB)
);

always #5 CLK = ~CLK;

initial begin

    CLK = 0;
    RegWEn = 0;
    AddrA = 0;
    AddrB = 0;
    AddrD = 0;
    DataD = 0;

    #10;

    AddrD = 5'b00001;
    DataD = 32'h0000000A;
    RegWEn = 1;
    #10;

    AddrD = 5'b11111;
    DataD = 32'hFFFFFFFF;
    RegWEn = 1;
    #10;

    AddrD = 5'b00000;
    DataD = 32'h12345678;
    RegWEn = 1;
    #10;

    AddrD = 5'b00010;
    DataD = 32'h0000000B;
    RegWEn = 0;
    #10;

    RegWEn = 0;
    AddrA = 5'b00001;
    AddrB = 5'b11111;
    #10;

    AddrA = 5'b00000;
    AddrB = 5'b00010;
    #10;

    $finish;
end

endmodule
