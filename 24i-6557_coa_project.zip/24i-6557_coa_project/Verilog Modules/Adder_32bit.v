
module Adder_32bit (
    input  [31:0] a,
    input  [31:0] b,
    input         cin,
    output [31:0] sum,
    output        cout
);
    wire [8:0] c;
    assign c[0] = cin;

    genvar i;
    generate
        for (i = 0; i < 8; i = i + 1) begin : stage
            Adder_4bit add4 (
                .a   (a[4*i +: 4]),
                .b   (b[4*i +: 4]),
                .cin (c[i]),
                .sum (sum[4*i +: 4]),
                .cout(c[i+1])
            );
        end
    endgenerate

    assign cout = c[8];
endmodule

module tb_Adder_32bit;
    reg  [31:0] a, b;
    reg         cin;
    wire [31:0] sum;
    wire        cout;

    Adder_32bit dut (.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

    initial begin
        a = 32'h00000000; b = 32'h00000000; cin = 0; #10;
        a = 32'h12345678; b = 32'h11111111; cin = 0; #10;
        a = 32'hFFFFFFFF; b = 32'h00000001; cin = 0; #10;
        a = 32'h00000005; b = 32'hFFFFFFFD; cin = 0; #10;
        a = 32'h7FFFFFFF; b = 32'h00000001; cin = 0; #10;
        a = 32'h0000FFFF; b = 32'h00000001; cin = 0; #10;
        a = 32'hFFFFFFFF; b = 32'hFFFFFFFF; cin = 0; #10;
        a = 32'h12345678; b = 32'h11111111; cin = 1; #10;
        a = 32'hFFFFFFFF; b = 32'h00000000; cin = 1; #10;
        $stop;
    end
endmodule
