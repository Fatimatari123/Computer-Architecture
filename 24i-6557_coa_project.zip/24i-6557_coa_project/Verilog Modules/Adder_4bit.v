
module Adder_4bit (
    input  [3:0] a,
    input  [3:0] b,
    input        cin,
    output [3:0] sum,
    output       cout
);
    wire c1, c2, c3;

    Full_Adder fa0 (.a(a[0]), .b(b[0]), .cin(cin), .sum(sum[0]), .cout(c1));
    Full_Adder fa1 (.a(a[1]), .b(b[1]), .cin(c1),  .sum(sum[1]), .cout(c2));
    Full_Adder fa2 (.a(a[2]), .b(b[2]), .cin(c2),  .sum(sum[2]), .cout(c3));
    Full_Adder fa3 (.a(a[3]), .b(b[3]), .cin(c3),  .sum(sum[3]), .cout(cout));
endmodule

module tb_Adder_4bit;
    reg  [3:0] a, b;
    reg        cin;
    wire [3:0] sum;
    wire       cout;

    Adder_4bit dut (.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

    initial begin
        a = 4'h0; b = 4'h0; cin = 0; #10;
        a = 4'h5; b = 4'h3; cin = 0; #10;
        a = 4'h7; b = 4'h8; cin = 0; #10;
        a = 4'hF; b = 4'h1; cin = 0; #10;
        a = 4'hF; b = 4'hF; cin = 0; #10;
        a = 4'h9; b = 4'h6; cin = 1; #10;
        a = 4'h3; b = 4'h4; cin = 1; #10;
        a = 4'hF; b = 4'hF; cin = 1; #10;
        $stop;
    end
endmodule
